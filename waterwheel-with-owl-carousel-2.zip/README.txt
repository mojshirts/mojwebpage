A Pen created at CodePen.io. You can find this one at https://codepen.io/pluibert/pen/yqdWXR.

 Waterwheel carousel made with Owl Carrousel 2